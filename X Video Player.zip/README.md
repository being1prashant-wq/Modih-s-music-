# Modih's Music Player

A local-first Android music player built with Kotlin, Jetpack Compose and Media3.

## Included in this revision
- Full-screen ModihMusic splash using the existing logo asset
- First-run welcome screen
- Red/black default brand theme plus Light, Pink, Blue, Purple, Green and Orange themes
- Home dashboard with Today's Best, Best New Songs, Recently Played, Artists and Albums
- Daily-stable featured song selection based on the local library
- Artwork-driven glass-style Now Playing screen
- Queue and lyrics panels
- Normal local playback queues all local songs; playlist playback queues only that playlist
- Persistent personal playlists and favourites
- Library: Songs, Artists, Albums, Playlists and Favourites
- Local library Search
- Online/YouTube tab retained with the existing compliant embedded player approach
- Settings opened from the top-right three-line menu
- Functional preferences for history, autoplay, shuffle, repeat, motion, contrast and supported audio effects
- Equalizer moved into Settings
- Four-tab bottom navigation: Home, Online, Library, Search
- Spring/jump tab animation and smooth content transitions
- Media3 background playback and media notification controls

## Build
Open the `OfflineMusicNew` folder in Android Studio and let Gradle sync. A Gradle wrapper was not included in the supplied base archive, so use the Gradle/Android Studio environment configured for the project.
