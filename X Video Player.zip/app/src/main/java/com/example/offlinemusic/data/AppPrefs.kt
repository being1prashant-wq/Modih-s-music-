package com.example.offlinemusic.data

import android.content.Context

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("modihmusic_prefs", Context.MODE_PRIVATE)

    var onboardingDone: Boolean
        get() = prefs.getBoolean("onboarding_done", false)
        set(value) = prefs.edit().putBoolean("onboarding_done", value).apply()

    var theme: String
        get() = prefs.getString("theme", "RED_DARK") ?: "RED_DARK"
        set(value) = prefs.edit().putString("theme", value).apply()

    var listeningHistory: Boolean
        get() = prefs.getBoolean("history", true)
        set(value) = prefs.edit().putBoolean("history", value).apply()

    var autoplay: Boolean
        get() = prefs.getBoolean("autoplay", true)
        set(value) = prefs.edit().putBoolean("autoplay", value).apply()

    var shuffle: Boolean
        get() = prefs.getBoolean("shuffle", false)
        set(value) = prefs.edit().putBoolean("shuffle", value).apply()

    var repeatOne: Boolean
        get() = prefs.getBoolean("repeat_one", false)
        set(value) = prefs.edit().putBoolean("repeat_one", value).apply()

    var animations: Boolean
        get() = prefs.getBoolean("animations", true)
        set(value) = prefs.edit().putBoolean("animations", value).apply()

    var highContrast: Boolean
        get() = prefs.getBoolean("high_contrast", false)
        set(value) = prefs.edit().putBoolean("high_contrast", value).apply()

    var notificationEnabled: Boolean
        get() = prefs.getBoolean("notifications", true)
        set(value) = prefs.edit().putBoolean("notifications", value).apply()

    var bassBoost: Boolean
        get() = prefs.getBoolean("bass_boost", false)
        set(value) = prefs.edit().putBoolean("bass_boost", value).apply()

    var soundCheck: Boolean
        get() = prefs.getBoolean("sound_check", false)
        set(value) = prefs.edit().putBoolean("sound_check", value).apply()

    fun clearHistory() = prefs.edit().remove("history_cleared_at").apply()
}
