package com.example.offlinemusic.ui.settings

import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.offlinemusic.data.AppPrefs
import com.example.offlinemusic.media.PlayerController
import com.example.offlinemusic.media.AudioEffectsManager
import com.example.offlinemusic.ui.equalizer.EqualizerScreen

@Composable
fun SettingsScreen(
    prefs: AppPrefs,
    currentTheme: String,
    onThemeChange: (String) -> Unit,
    onRescan: () -> Unit,
    onClose: () -> Unit,
    playerController: PlayerController
) {
    var showThemes by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { AudioEffectsManager.setBassBoost(prefs.bassBoost); AudioEffectsManager.setSoundCheck(prefs.soundCheck) }
    var showEqualizer by remember { mutableStateOf(false) }
    if (showEqualizer) {
        EqualizerScreen(onClose = { showEqualizer = false })
        return
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Back", tint = MaterialTheme.colorScheme.primary) }
            Text("Settings", color = MaterialTheme.colorScheme.onBackground, fontSize = 28.sp)
        }
        androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize()) {
            item { SectionTitle("Library") }
            item { SettingRow("Rescan Music Library", "Scan the device for new local songs", onClick = onRescan, trailing = { Icon(Icons.Default.Refresh, null, tint = MaterialTheme.colorScheme.primary) }) }
            item { SettingRow("Use Listening History", "Recently played and play counts", switch = prefs.listeningHistory, onSwitch = { prefs.listeningHistory = it }) }
            item { HorizontalDivider() }
            item { SectionTitle("Playback") }
            item { SettingRow("Autoplay", "Continue through the active queue", switch = prefs.autoplay, onSwitch = { prefs.autoplay = it }) }
            item { SettingRow("Shuffle by Default", "Start normal library playback shuffled", switch = prefs.shuffle, onSwitch = { prefs.shuffle = it }) }
            item { SettingRow("Repeat Current Song", "Keep the current song repeating", switch = prefs.repeatOne, onSwitch = { prefs.repeatOne = it }) }
            item { SettingRow("Gapless Playback", "Media3 keeps transitions continuous when the source/device supports it") }
            item { HorizontalDivider() }
            item { SectionTitle("Audio") }
            item { SettingRow("Equalizer", "Open the working Android audio equalizer", onClick = { showEqualizer = true }, trailing = { Icon(Icons.Default.Equalizer, null, tint = MaterialTheme.colorScheme.primary) }) }
            item { SettingRow("Bass Boost", "Enable a device audio bass effect when supported", switch = prefs.bassBoost, onSwitch = { prefs.bassBoost = it; AudioEffectsManager.setBassBoost(it) }) }
            item { SettingRow("Sound Check", "Apply a gentle output gain effect where supported", switch = prefs.soundCheck, onSwitch = { prefs.soundCheck = it; AudioEffectsManager.setSoundCheck(it) }) }

            item { HorizontalDivider() }
            item { SectionTitle("Display Options") }
            item { SettingRow("Theme", themeLabel(currentTheme), onClick = { showThemes = true }) }
            item { SettingRow("Motion", "Enable smooth tab and player animations", switch = prefs.animations, onSwitch = { prefs.animations = it }) }
            item { SettingRow("Increase Contrast", "Increase foreground/background contrast", switch = prefs.highContrast, onSwitch = { prefs.highContrast = it }) }
            item { HorizontalDivider() }
            item { SectionTitle("Storage") }
            item { SettingRow("Device Storage", freeSpaceText()) }

            item { HorizontalDivider() }
            item { SectionTitle("App") }
            item { SettingRow("About Modih's Music", "Version 3.0 • Local-first music player") }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
    if (showThemes) {
        val themes = listOf("RED_DARK" to "Dark Red", "LIGHT" to "Light", "PINK" to "Pink", "BLUE" to "Blue", "PURPLE" to "Purple", "GREEN" to "Green", "ORANGE" to "Orange")
        AlertDialog(
            onDismissRequest = { showThemes = false },
            title = { Text("Choose Theme") },
            text = { Column { themes.forEach { (key, label) -> TextButton(onClick = { onThemeChange(key); showThemes = false }, modifier = Modifier.fillMaxWidth()) { Text(label, color = if (key == currentTheme) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) } } } },
            confirmButton = { TextButton(onClick = { showThemes = false }) { Text("Done") } }
        )
    }
}

@Composable private fun SectionTitle(title: String) {
    Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp))
}

@Composable private fun SettingRow(
    title: String,
    subtitle: String = "",
    switch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val rowModifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    Row(
        rowModifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).then(if (onClick != null) Modifier else Modifier)) {
            Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        when {
            switch != null && onSwitch != null -> Switch(checked = switch, onCheckedChange = onSwitch)
            trailing != null -> trailing()
        }
    }
}

private fun themeLabel(key: String) = mapOf("RED_DARK" to "Dark Red", "LIGHT" to "Light", "PINK" to "Pink", "BLUE" to "Blue", "PURPLE" to "Purple", "GREEN" to "Green", "ORANGE" to "Orange")[key] ?: "Dark Red"

private fun freeSpaceText(): String = runCatching {
    val stat = StatFs(android.os.Environment.getDataDirectory().path)
    val gb = stat.availableBytes / 1024.0 / 1024.0 / 1024.0
    "%.1f GB free".format(gb)
}.getOrDefault("Storage unavailable")
