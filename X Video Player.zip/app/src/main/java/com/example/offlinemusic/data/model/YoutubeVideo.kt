package com.example.offlinemusic.data.model

data class YoutubeVideo(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String,
    val description: String = ""
)
