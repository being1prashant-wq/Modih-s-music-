package com.example.offlinemusic.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.ui.components.SongListItem

@Composable
fun SearchScreen(allSongs: List<Song>, onPlaySong: (Song) -> Unit) {
    var query by remember { mutableStateOf("") }
    val q = query.trim().lowercase()
    val results = if (q.isBlank()) emptyList() else allSongs.filter {
        it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 16.dp)) {
        Text("Search", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 10.dp, bottom = 12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.padding(bottom = 12.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Songs, artists, albums, playlists") }
        )
        if (q.isBlank()) Text("Search your local music library.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
        else if (results.isEmpty()) Text("No results", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
        else LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) { items(results, key = { it.id }) { song -> SongListItem(song) { onPlaySong(song) } } }
    }
}
