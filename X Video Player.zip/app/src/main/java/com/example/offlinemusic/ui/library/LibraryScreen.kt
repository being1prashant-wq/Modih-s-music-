package com.example.offlinemusic.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.offlinemusic.data.PlaylistStore
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.components.SongListItem

@Composable
fun LibraryScreen(
    playlistStore: PlaylistStore,
    allSongsProvider: () -> List<Song>,
    favoriteSongsProvider: suspend () -> List<Song>,
    onPlaySong: (Song, List<Song>) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var songs by remember { mutableStateOf(allSongsProvider()) }
    var playlists by remember { mutableStateOf(playlistStore.load()) }
    var createDialog by remember { mutableStateOf(false) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var addSong by remember { mutableStateOf<Song?>(null) }
    var renamePlaylist by remember { mutableStateOf<String?>(null) }
    var favoriteSongs by remember { mutableStateOf<List<Song>>(emptyList()) }

    LaunchedEffect(Unit) { songs = allSongsProvider(); playlists = playlistStore.load(); favoriteSongs = favoriteSongsProvider() }

    val tabs = listOf("Songs", "Artists", "Albums", "Playlists", "Favourites")
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            Text("Library", color = MaterialTheme.colorScheme.onBackground, fontSize = 32.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
            androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab, edgePadding = 14.dp, containerColor = MaterialTheme.colorScheme.background) {
                tabs.forEachIndexed { i, title -> androidx.compose.material3.Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) }) }
            }
            when (tab) {
                0 -> SongList(songs, onPlaySong, playlists, { addSong = it })
                1 -> ArtistList(songs)
                2 -> AlbumList(songs, onPlaySong)
                3 -> PlaylistList(playlists, songs, playlistStore, onPlaySong, { playlists = playlistStore.load() }, { createDialog = true }, selectedPlaylist, { selectedPlaylist = it }, { renamePlaylist = it })
                else -> SongList(favoriteSongs, onPlaySong, playlists, { addSong = it })
            }
        }
    }
    if (createDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { createDialog = false },
            title = { Text("Create playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Playlist name") }) },
            confirmButton = { Button(onClick = { if (playlistStore.create(name)) playlists = playlistStore.load(); createDialog = false }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { createDialog = false }) { Text("Cancel") } }
        )
    }
    addSong?.let { song ->
        AlertDialog(
            onDismissRequest = { addSong = null },
            title = { Text("Add to playlist") },
            text = { Column {
                if (playlists.isEmpty()) Text("Create a playlist first.")
                playlists.keys.forEach { name -> TextButton(onClick = { playlistStore.addSong(name, song.id); addSong = null; playlists = playlistStore.load() }, modifier = Modifier.fillMaxWidth()) { Text(name) } }
            } },
            confirmButton = { TextButton(onClick = { addSong = null }) { Text("Close") } }
        )
    }    renamePlaylist?.let { oldName ->
        var newName by remember(oldName) { mutableStateOf(oldName) }
        AlertDialog(
            onDismissRequest = { renamePlaylist = null },
            title = { Text("Rename playlist") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true) },
            confirmButton = { Button(onClick = { if (playlistStore.rename(oldName, newName)) playlists = playlistStore.load(); renamePlaylist = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renamePlaylist = null }) { Text("Cancel") } }
        )
    }
}

@Composable private fun SongList(
    songs: List<Song>,
    onPlaySong: (Song, List<Song>) -> Unit,
    playlists: Map<String, MutableList<Long>>,
    onAddSong: (Song) -> Unit
) {
    if (songs.isEmpty()) Text("No local songs found.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), modifier = Modifier.padding(24.dp))
    else LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
        items(songs, key = { it.id }) { song ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { SongListItem(song) { onPlaySong(song, songs) } }
                IconButton(onClick = { onAddSong(song) }) { Icon(Icons.Default.Add, "Add to playlist", tint = MaterialTheme.colorScheme.primary) }
            }
        }
    }
}

@Composable private fun ArtistList(songs: List<Song>) {
    val artists = songs.groupBy { it.artist.ifBlank { "Unknown Artist" } }
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
        items(artists.toList(), key = { it.first }) { (artist, list) ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassCard(Modifier.size(54.dp), 27.dp) { Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.Center)) }
                Spacer(Modifier.size(14.dp)); Column { Text(artist, color = MaterialTheme.colorScheme.onBackground); Text("${list.size} songs", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp) }
            }
        }
    }
}

@Composable private fun AlbumList(songs: List<Song>, onPlaySong: (Song, List<Song>) -> Unit) {
    val albums = songs.groupBy { it.album.ifBlank { "Unknown Album" } }
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
        items(albums.toList(), key = { it.first }) { (album, list) ->
            Row(Modifier.fillMaxWidth().clickable { list.firstOrNull()?.let { onPlaySong(it, list) } }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassCard(Modifier.size(62.dp), 12.dp) { list.firstOrNull()?.albumArtUri?.let { AsyncImage(it, null, Modifier.fillMaxSize()) } ?: Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.Center)) }
                Spacer(Modifier.size(14.dp)); Column(Modifier.weight(1f)) { Text(album, color = MaterialTheme.colorScheme.onBackground); Text("${list.size} songs", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp) }
                Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable private fun PlaylistList(
    playlists: Map<String, MutableList<Long>>,
    songs: List<Song>,
    store: PlaylistStore,
    onPlaySong: (Song, List<Song>) -> Unit,
    onRefresh: () -> Unit,
    onCreate: () -> Unit,
    selected: String?,
    onSelect: (String?) -> Unit,
    onRename: (String) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Personal Playlists", color = MaterialTheme.colorScheme.onBackground, fontSize = 20.sp)
            IconButton(onClick = onCreate) { Icon(Icons.Default.Add, "Create playlist", tint = MaterialTheme.colorScheme.primary) }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
            items(playlists.toList(), key = { it.first }) { (name, ids) ->
                val list = ids.mapNotNull { id -> songs.firstOrNull { it.id == id } }
                Row(Modifier.fillMaxWidth().clickable { onSelect(if (selected == name) null else name) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassCard(Modifier.size(56.dp), 14.dp) { Icon(Icons.Default.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.Center).size(32.dp)) }
                    Spacer(Modifier.size(14.dp)); Column(Modifier.weight(1f)) { Text(name, color = MaterialTheme.colorScheme.onBackground); Text("${list.size} songs", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp) }
                    if (list.isNotEmpty()) IconButton(onClick = { onPlaySong(list.first(), list) }) { Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary) }
                    IconButton(onClick = { onRename(name) }) { Icon(Icons.Default.Edit, "Rename", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
                    IconButton(onClick = { store.delete(name); onRefresh() }) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
                }
                if (selected == name) {
                    list.forEach { song ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { SongListItem(song) { onPlaySong(song, list) } }
                            IconButton(onClick = { store.removeSong(name, song.id); onRefresh() }) { Icon(Icons.Default.Delete, "Remove", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .45f)) }
                        }
                    }
                    Text("Tap a song to play from this playlist.\nUse Search/Library actions to add songs.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
                }
            }
        }
    }
}
