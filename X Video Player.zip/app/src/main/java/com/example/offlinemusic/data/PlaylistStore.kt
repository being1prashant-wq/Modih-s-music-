package com.example.offlinemusic.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PlaylistStore(context: Context) {
    private val prefs = context.getSharedPreferences("modihmusic_playlists", Context.MODE_PRIVATE)

    fun load(): LinkedHashMap<String, MutableList<Long>> {
        val result = linkedMapOf<String, MutableList<Long>>()
        val raw = prefs.getString("data", "{}") ?: "{}"
        runCatching {
            val root = JSONObject(raw)
            root.keys().forEach { name ->
                val arr = root.optJSONArray(name) ?: JSONArray()
                val ids = mutableListOf<Long>()
                for (i in 0 until arr.length()) ids += arr.optLong(i)
                result[name] = ids
            }
        }
        return result
    }

    private fun save(data: Map<String, List<Long>>) {
        val root = JSONObject()
        data.forEach { (name, ids) ->
            root.put(name, JSONArray(ids))
        }
        prefs.edit().putString("data", root.toString()).apply()
    }

    fun create(name: String): Boolean {
        val clean = name.trim()
        if (clean.isBlank()) return false
        val data = load()
        if (data.containsKey(clean)) return false
        data[clean] = mutableListOf()
        save(data)
        return true
    }

    fun rename(old: String, new: String): Boolean {
        val clean = new.trim()
        if (clean.isBlank()) return false
        val data = load()
        if (!data.containsKey(old) || (old != clean && data.containsKey(clean))) return false
        val songs = data.remove(old) ?: mutableListOf()
        data[clean] = songs
        save(data)
        return true
    }

    fun delete(name: String) {
        val data = load()
        data.remove(name)
        save(data)
    }

    fun addSong(name: String, songId: Long) {
        val data = load()
        val list = data[name] ?: mutableListOf()
        if (!list.contains(songId)) list += songId
        data[name] = list
        save(data)
    }

    fun removeSong(name: String, songId: Long) {
        val data = load()
        data[name]?.remove(songId)
        save(data)
    }
}
