package com.example.offlinemusic.ui.theme

import androidx.compose.ui.graphics.Color

data class AppColors(
    val primary: Color,
    val primaryDark: Color,
    val background: Color,
    val surface: Color,
    val surface2: Color,
    val text: Color,
    val secondaryText: Color,
    val mutedText: Color
)

val RedDarkColors = AppColors(
    primary = Color(0xFFE53935), primaryDark = Color(0xFFB71C1C),
    background = Color(0xFF090909), surface = Color(0xFF171717), surface2 = Color(0xFF222222),
    text = Color.White, secondaryText = Color(0xFFD0D0D0), mutedText = Color(0xFF969696)
)
val LightColors = AppColors(
    primary = Color(0xFFD81B28), primaryDark = Color(0xFFA20F1A),
    background = Color(0xFFF7F7F7), surface = Color.White, surface2 = Color(0xFFECECEC),
    text = Color(0xFF171717), secondaryText = Color(0xFF555555), mutedText = Color(0xFF777777)
)
val PinkColors = RedDarkColors.copy(primary = Color(0xFFFF4081), primaryDark = Color(0xFFC2185B))
val BlueColors = RedDarkColors.copy(primary = Color(0xFF448AFF), primaryDark = Color(0xFF1565C0))
val PurpleColors = RedDarkColors.copy(primary = Color(0xFFB388FF), primaryDark = Color(0xFF6A1B9A))
val GreenColors = RedDarkColors.copy(primary = Color(0xFF69F0AE), primaryDark = Color(0xFF2E7D32))
val OrangeColors = RedDarkColors.copy(primary = Color(0xFFFF7043), primaryDark = Color(0xFFE65100))

fun appColorsFor(name: String): AppColors = when (name) {
    "LIGHT" -> LightColors
    "PINK" -> PinkColors
    "BLUE" -> BlueColors
    "PURPLE" -> PurpleColors
    "GREEN" -> GreenColors
    "ORANGE" -> OrangeColors
    else -> RedDarkColors
}

val GlassWhite = Color(0x33FFFFFF)
val GlassWhiteStrong = Color(0x55FFFFFF)
val GlassBorder = Color(0x44FFFFFF)
val AccentPurple = Color(0xFFBB86FC)
val AccentPink = Color(0xFFFF79C6)
val AccentBlue = Color(0xFF82B1FF)
val DarkBg = Color(0xFF0D0D0D)
val DarkBg2 = Color(0xFF1A1A1A)
val TextPrimary = Color.White
val TextSecondary = Color(0xCCFFFFFF)
val TextMuted = Color(0x88FFFFFF)
