package com.example.offlinemusic.ui.online

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.offlinemusic.data.YoutubeRepository
import com.example.offlinemusic.data.model.YoutubeVideo
import com.example.offlinemusic.ui.components.GlassCard
import kotlinx.coroutines.launch

@Composable
fun OnlineMusicScreen() {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<YoutubeVideo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedVideo by remember { mutableStateOf<YoutubeVideo?>(null) }

    val scope = rememberCoroutineScope()
    val repo = remember { YoutubeRepository() }
    val keyboard = LocalSoftwareKeyboardController.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.background)))
    ) {
        if (selectedVideo != null) {
            val isMusic = repo.isLikelyMusic(selectedVideo!!)
            if (isMusic) {
                MusicStylePlayer(
                    video = selectedVideo!!,
                    repo = repo,
                    onClose = { selectedVideo = null },
                    onPlayRelated = { selectedVideo = it }
                )
            } else {
                VideoStylePlayer(
                    video = selectedVideo!!,
                    repo = repo,
                    onClose = { selectedVideo = null },
                    onPlayRelated = { selectedVideo = it }
                )
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Text(
                    text = "Online Music",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
                )

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    placeholder = { Text("Search songs / videos on YouTube…", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            keyboard?.hide()
                            if (query.isNotBlank()) {
                                scope.launch {
                                    isLoading = true
                                    errorMessage = null
                                    results = repo.searchVideos(query.trim())
                                    isLoading = false
                                    if (results.isEmpty()) {
                                        errorMessage =
                                            "No results or API key missing.\nPut your YouTube Data API key in YoutubeRepository.kt"
                                    }
                                }
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                        focusedTextColor = MaterialTheme.colorScheme.onBackground,
                        unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedContainerColor = Color.White.copy(alpha = 0.08f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(Modifier.height(12.dp))

                when {
                    isLoading -> {
                        Box(
                            Modifier.fillMaxSize().padding(top = 60.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    errorMessage != null -> {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                            fontSize = 14.sp,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                    results.isEmpty() -> {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                "Search any song or video",
                                color = MaterialTheme.colorScheme.onBackground,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Songs → Music UI\nVideos → Video UI\nBoth play inside the app",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                                fontSize = 14.sp
                            )
                        }
                    }
                    else -> {
                        LazyColumn(contentPadding = PaddingValues(bottom = 100.dp, top = 8.dp)) {
                            items(results) { video ->
                                YoutubeResultItem(
                                    video = video,
                                    isMusic = repo.isLikelyMusic(video),
                                    onClick = { selectedVideo = video }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YoutubeResultItem(
    video: YoutubeVideo,
    isMusic: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassCard(
            modifier = Modifier
                .width(120.dp)
                .aspectRatio(16f / 9f),
            cornerRadius = 12.dp
        ) {
            AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = video.title,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Icon(
                Icons.Default.PlayArrow,
                null,
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(36.dp)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50))
                    .padding(4.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = video.channelTitle,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = if (isMusic) "♪ Music" else "▶ Video",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun MusicStylePlayer(
    video: YoutubeVideo,
    repo: YoutubeRepository,
    onClose: () -> Unit,
    onPlayRelated: (YoutubeVideo) -> Unit
) {
    var showSuggestions by remember { mutableStateOf(false) }
    var related by remember { mutableStateOf<List<YoutubeVideo>>(emptyList()) }
    var loadingRelated by remember { mutableStateOf(false) }

    LaunchedEffect(video.videoId) {
        loadingRelated = true
        related = repo.getRelatedVideos(video.videoId)
        loadingRelated = false
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A0A2E), MaterialTheme.colorScheme.background)))) {
        AsyncImage(
            model = video.thumbnailUrl,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.2f
        )

        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, null, tint = MaterialTheme.colorScheme.onBackground)
                }
                Text(
                    "Now Playing • Music",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showSuggestions = !showSuggestions }) {
                    Icon(
                        Icons.Default.List,
                        contentDescription = "Suggestions",
                        tint = if (showSuggestions) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            GlassCard(
                modifier = Modifier
                    .padding(horizontal = 40.dp)
                    .fillMaxWidth()
                    .aspectRatio(1f),
                cornerRadius = 28.dp,
                strong = true
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                video.title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 28.dp)
            )
            Text(
                video.channelTitle,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 28.dp, vertical = 4.dp)
            )

            Spacer(Modifier.height(16.dp))

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(220.dp),
                cornerRadius = 16.dp
            ) {
                YoutubeWebPlayer(videoId = video.videoId)
            }

            if (showSuggestions) {
                Spacer(Modifier.height(16.dp))
                Text(
                    "Suggestions",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                if (loadingRelated) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(20.dp).align(Alignment.CenterHorizontally)
                    )
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
                        items(related) { item ->
                            YoutubeResultItem(
                                video = item,
                                isMusic = repo.isLikelyMusic(item),
                                onClick = { onPlayRelated(item) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoStylePlayer(
    video: YoutubeVideo,
    repo: YoutubeRepository,
    onClose: () -> Unit,
    onPlayRelated: (YoutubeVideo) -> Unit
) {
    var related by remember { mutableStateOf<List<YoutubeVideo>>(emptyList()) }
    var loadingRelated by remember { mutableStateOf(false) }

    LaunchedEffect(video.videoId) {
        loadingRelated = true
        related = repo.getRelatedVideos(video.videoId)
        loadingRelated = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xEE111111))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, null, tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    video.title,
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    video.channelTitle,
                    color = Color.Gray,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Icon(Icons.Default.VideoLibrary, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 8.dp))
        }

        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
        ) {
            YoutubeWebPlayer(videoId = video.videoId)
        }

        Text(
            "Up next / Suggestions",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )

        if (loadingRelated) {
            Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
                items(related) { item ->
                    YoutubeResultItem(
                        video = item,
                        isMusic = repo.isLikelyMusic(item),
                        onClick = { onPlayRelated(item) }
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YoutubeWebPlayer(videoId: String) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()

                val html = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
                        <style>
                            body { margin:0; background:#000; }
                            .player { position:fixed; top:0; left:0; width:100%; height:100%; }
                        </style>
                    </head>
                    <body>
                        <div class="player">
                            <iframe 
                                width="100%" 
                                height="100%" 
                                src="https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&rel=0&modestbranding=1"
                                frameborder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowfullscreen>
                            </iframe>
                        </div>
                    </body>
                    </html>
                """.trimIndent()

                loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
