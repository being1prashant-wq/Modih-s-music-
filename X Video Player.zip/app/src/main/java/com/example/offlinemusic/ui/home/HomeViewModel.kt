package com.example.offlinemusic.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinemusic.data.MusicRepository
import com.example.offlinemusic.data.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MusicRepository(app)

    private val _allSongs = MutableStateFlow<List<Song>>(emptyList())
    val allSongs: StateFlow<List<Song>> = _allSongs.asStateFlow()

    private val _recentlyPlayed = MutableStateFlow<List<Song>>(emptyList())
    val recentlyPlayed: StateFlow<List<Song>> = _recentlyPlayed.asStateFlow()

    private val _mostPlayed = MutableStateFlow<List<Song>>(emptyList())
    val mostPlayed: StateFlow<List<Song>> = _mostPlayed.asStateFlow()

    private val _yourSongs = MutableStateFlow<List<Song>>(emptyList())
    val yourSongs: StateFlow<List<Song>> = _yourSongs.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _loading.value = true
            val songs = repo.loadSongs(forceRefresh = true)
            _allSongs.value = songs
            _yourSongs.value = songs.take(8)
            _recentlyPlayed.value = repo.getRecentlyPlayedSongs(10).ifEmpty {
                songs.take(8)
            }
            _mostPlayed.value = repo.getMostPlayedSongs(10).ifEmpty {
                songs.shuffled().take(8)
            }
            _loading.value = false
        }
    }

    fun recordPlay(song: Song) {
        viewModelScope.launch {
            repo.recordPlay(song.id)
            // refresh lists
            _recentlyPlayed.value = repo.getRecentlyPlayedSongs(10)
            _mostPlayed.value = repo.getMostPlayedSongs(10)
        }
    }
}
