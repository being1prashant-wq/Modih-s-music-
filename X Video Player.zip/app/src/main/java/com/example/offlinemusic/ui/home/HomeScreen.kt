package com.example.offlinemusic.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.components.SongCard
import com.example.offlinemusic.ui.components.SongListItem
import java.util.Calendar

@Composable
fun HomeScreen(
    onPlaySong: (Song, List<Song>) -> Unit,
    onViewAllSongs: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val loading by viewModel.loading.collectAsState()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsState()
    val allSongs by viewModel.allSongs.collectAsState()
    val bestSongs = allSongs.sortedByDescending { it.dateAdded }.take(12)
    val featured = if (allSongs.isNotEmpty()) {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        allSongs[day % allSongs.size]
    } else null
    val artists = allSongs.groupBy { it.artist.ifBlank { "Unknown Artist" } }.entries.take(12)
    val albums = allSongs.groupBy { it.album.ifBlank { "Unknown Album" } }.entries.take(12)

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.primary)
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
                item {
                    Text("Home", color = MaterialTheme.colorScheme.onBackground, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                }
                if (featured != null) {
                    item {
                        FeaturedSongCard(featured, onClick = { onPlaySong(featured, allSongs) })
                    }
                }
                item { SectionHeader("Best New Songs", "Show All", onViewAllSongs) }
                item {
                    if (bestSongs.isEmpty()) EmptyLibrary()
                    else Column { bestSongs.take(5).forEach { song -> SongListItem(song, { onPlaySong(song, allSongs) }) } }
                }
                item { Spacer(Modifier.height(22.dp)) }
                item { SectionHeader("Recently Played", null, null) }
                item {
                    val recent = recentlyPlayed.ifEmpty { allSongs.take(8) }
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(recent, key = { it.id }) { song -> SongCard(song, { onPlaySong(song, allSongs) }, width = 142) }
                    }
                }
                item { Spacer(Modifier.height(26.dp)) }
                item { SectionHeader("Artists", "Show All", onViewAllSongs) }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(artists.toList(), key = { it.key }) { (artist, songs) ->
                            ArtistCard(artist, songs.firstOrNull(), songs.size)
                        }
                    }
                }
                item { Spacer(Modifier.height(26.dp)) }
                item { SectionHeader("Albums", "Show All", onViewAllSongs) }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(albums.toList(), key = { it.key }) { (album, songs) ->
                            AlbumCard(album, songs.firstOrNull(), songs.size)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeaturedSongCard(song: Song, onClick: () -> Unit) {
    GlassCard(Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth().aspectRatio(1.55f).clickable(onClick = onClick), 24.dp, true) {
        if (song.albumArtUri != null) AsyncImage(song.albumArtUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = .88f)
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = .25f)))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Text("TODAY'S BEST", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(song.title, color = MaterialTheme.colorScheme.onBackground, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .75f), fontSize = 14.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String?, onAction: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        if (action != null && onAction != null) TextButton(onClick = onAction) { Text(action, color = MaterialTheme.colorScheme.primary) }
    }
}

@Composable
private fun ArtistCard(name: String, song: Song?, count: Int) {
    Column(Modifier.width(145.dp)) {
        GlassCard(Modifier.fillMaxWidth().aspectRatio(1f), 18.dp) {
            if (song?.albumArtUri != null) AsyncImage(song.albumArtUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else androidx.compose.material3.Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f), modifier = Modifier.align(Alignment.Center).padding(28.dp))
        }
        Spacer(Modifier.height(8.dp)); Text(name, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count songs", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp)
    }
}

@Composable
private fun AlbumCard(name: String, song: Song?, count: Int) {
    Column(Modifier.width(155.dp)) {
        GlassCard(Modifier.fillMaxWidth().aspectRatio(1f), 18.dp) {
            if (song?.albumArtUri != null) AsyncImage(song.albumArtUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else androidx.compose.material3.Icon(Icons.Default.Album, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f), modifier = Modifier.align(Alignment.Center).padding(28.dp))
        }
        Spacer(Modifier.height(8.dp)); Text(name, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count songs", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp)
    }
}

@Composable
private fun EmptyLibrary() {
    Text("No local songs found yet. Add music to your device and rescan the library.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), modifier = Modifier.padding(20.dp))
}
