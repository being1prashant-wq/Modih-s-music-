package com.example.offlinemusic.media

import android.media.audiofx.BassBoost
import android.media.audiofx.LoudnessEnhancer

object AudioEffectsManager {
    private var bass: BassBoost? = null
    private var loudness: LoudnessEnhancer? = null

    fun setBassBoost(enabled: Boolean) {
        runCatching {
            if (bass == null) bass = BassBoost(0, 0)
            bass?.setStrength(if (enabled) 700 else 0).toShort()
            bass?.enabled = enabled
        }
    }

    fun setSoundCheck(enabled: Boolean) {
        runCatching {
            if (loudness == null) loudness = LoudnessEnhancer(0)
            loudness?.setTargetGain(if (enabled) 450 else 0)
            loudness?.enabled = enabled
        }
    }

    fun release() {
        runCatching { bass?.release() }
        runCatching { loudness?.release() }
        bass = null
        loudness = null
    }
}
