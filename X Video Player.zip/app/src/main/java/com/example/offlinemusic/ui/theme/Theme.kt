package com.example.offlinemusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun ModihMusicTheme(
    themeName: String,
    content: @Composable () -> Unit
) {
    val c = appColorsFor(themeName)
    val scheme = if (themeName == "LIGHT") {
        lightColorScheme(
            primary = c.primary, secondary = c.primaryDark, tertiary = c.primary,
            background = c.background, surface = c.surface,
            onPrimary = Color.White, onSecondary = Color.White,
            onBackground = c.text, onSurface = c.text
        )
    } else {
        darkColorScheme(
            primary = c.primary, secondary = c.primaryDark, tertiary = c.primary,
            background = c.background, surface = c.surface,
            onPrimary = Color.White, onSecondary = Color.White,
            onBackground = c.text, onSurface = c.text
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun OfflineMusicGlassTheme(content: @Composable () -> Unit) = ModihMusicTheme("RED_DARK", content)
