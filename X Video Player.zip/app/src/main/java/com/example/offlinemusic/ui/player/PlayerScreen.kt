package com.example.offlinemusic.ui.player

import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import com.example.offlinemusic.data.MusicRepository
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.media.PlayerController
import com.example.offlinemusic.ui.components.GlassCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(
    playerController: PlayerController,
    allSongs: List<Song>,
    onClose: () -> Unit,
    onFavoriteChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    val repo = remember { MusicRepository(context) }
    val song by playerController.currentSong.collectAsState()
    val playing by playerController.isPlaying.collectAsState()
    val position by playerController.position.collectAsState()
    val duration by playerController.duration.collectAsState()
    val queue by playerController.queue.collectAsState()
    var favorite by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var dominant by remember { mutableStateOf(Color(0xFFB71C1C)) }

    LaunchedEffect(song?.id) {
        song?.let { favorite = repo.isFavorite(it.id) }
        dominant = song?.albumArtUri?.let { uri ->
            withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        val bmp = BitmapFactory.decodeStream(stream)
                        Palette.from(bmp).generate().getDominantColor(android.graphics.Color.rgb(183, 28, 28))
                    }
                }.getOrNull()
            }
        }?.let { Color(it) } ?: Color(0xFFB71C1C)
    }
    LaunchedEffect(Unit) { while (true) { playerController.updatePosition(); delay(500) } }

    val current = song ?: return
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(dominant.copy(alpha = .88f), MaterialTheme.colorScheme.background, Color.Black)))) {
        song?.albumArtUri?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = .13f) }
        LazyColumn(horizontalAlignment = Alignment.CenterHorizontally, contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 30.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Close", tint = Color.White) }
                    Text("Now Playing", color = Color.White.copy(alpha = .75f))
                    IconButton(onClick = { favorite = !favorite; kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { repo.toggleFavorite(current.id) }; onFavoriteChanged() }) {
                        Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favourite", tint = if (favorite) MaterialTheme.colorScheme.primary else Color.White)
                    }
                }
            }
            item {
                GlassCard(Modifier.padding(horizontal = 28.dp).fillMaxWidth().aspectRatio(1f), 30.dp, true) {
                    current.albumArtUri?.let { AsyncImage(it, current.title, Modifier.fillMaxSize().clip(RoundedCornerShape(30.dp)), contentScale = ContentScale.Crop) }
                        ?: Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(80.dp))
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(current.title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(current.artist, color = Color.White.copy(alpha = .68f), fontSize = 15.sp, maxLines = 1)
                    }
                    IconButton(onClick = { showLyrics = true }) { Icon(Icons.Default.List, "Lyrics", tint = Color.White) }
                }
            }
            item {
                Column(Modifier.padding(horizontal = 24.dp)) {
                    Slider(
                        value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                        onValueChange = { playerController.seekTo((it * duration).toLong()) },
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = .25f))
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), color = Color.White.copy(alpha = .65f), fontSize = 12.sp); Text("-${formatTime((duration - position).coerceAtLeast(0))}", color = Color.White.copy(alpha = .65f), fontSize = 12.sp) }
                }
            }
            item { Spacer(Modifier.height(14.dp)) }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shuffle = !shuffle; playerController.setShuffle(shuffle) }) { Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffle) MaterialTheme.colorScheme.primary else Color.White) }
                    IconButton(onClick = { playerController.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(38.dp)) }
                    IconButton(onClick = { playerController.togglePlayPause() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(64.dp)) }
                    IconButton(onClick = { playerController.seekToNext() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(38.dp)) }
                    IconButton(onClick = { playerController.setRepeatMode(androidx.media3.common.Player.REPEAT_MODE_ONE) }) { Icon(Icons.Default.Repeat, "Repeat", tint = Color.White) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 20.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = { showLyrics = true }) { Text("Lyrics", color = Color.White) }
                    TextButton(onClick = { showQueue = true }) { Text("Queue (${queue.size})", color = Color.White) }
                }
            }
        }
    }

    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }) {
            Text("Queue", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp))
            LazyColumn(Modifier.fillMaxWidth()) { items(queue, key = { it.id }) { item ->
                Text(item.title + " • " + item.artist, color = if (item.id == current.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
            } }
        }
    }
    if (showLyrics) {
        ModalBottomSheet(onDismissRequest = { showLyrics = false }) {
            Column(Modifier.fillMaxWidth().padding(24.dp)) {
                Text("Lyrics", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(14.dp))
                Text("Lyrics are not embedded in this local file.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                Text("Add lyric metadata to the file or integrate a licensed lyrics provider to display synced lyrics.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val sec = (ms / 1000).toInt().coerceAtLeast(0)
    return "%d:%02d".format(sec / 60, sec % 60)
}
