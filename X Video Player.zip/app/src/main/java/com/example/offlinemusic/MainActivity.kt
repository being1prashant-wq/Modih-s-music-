package com.example.offlinemusic

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinemusic.data.AppPrefs
import com.example.offlinemusic.data.MusicRepository
import com.example.offlinemusic.data.PlaylistStore
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.media.PlayerController
import com.example.offlinemusic.ui.components.MiniPlayer
import com.example.offlinemusic.ui.home.HomeScreen
import com.example.offlinemusic.ui.library.LibraryScreen
import com.example.offlinemusic.ui.online.OnlineMusicScreen
import com.example.offlinemusic.ui.player.PlayerScreen
import com.example.offlinemusic.ui.search.SearchScreen
import com.example.offlinemusic.ui.settings.SettingsScreen
import com.example.offlinemusic.ui.theme.ModihMusicTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var playerController: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        playerController = PlayerController(this)
        playerController.connect()
        setContent { ModihMusicRoot(playerController) }
    }

    override fun onDestroy() {
        playerController.disconnect()
        super.onDestroy()
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
private fun ModihMusicRoot(playerController: PlayerController) {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val playlistStore = remember { PlaylistStore(context) }
    val repo = remember { MusicRepository(context) }
    var themeName by remember { mutableStateOf(prefs.theme) }
    var splash by remember { mutableStateOf(true) }
    var onboarded by remember { mutableStateOf(prefs.onboardingDone) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var showPlayer by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var allSongs by remember { mutableStateOf<List<Song>>(emptyList()) }

    LaunchedEffect(Unit) {
        delay(1150)
        splash = false
    }
    LaunchedEffect(onboarded, refreshKey) {
        if (onboarded) allSongs = repo.loadSongs(forceRefresh = true)
    }

    ModihMusicTheme(themeName) {
        when {
            splash -> SplashScreen()
            !onboarded -> WelcomeScreen {
                prefs.onboardingDone = true
                onboarded = true
            }
            else -> {
                val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Manifest.permission.READ_MEDIA_AUDIO
                } else Manifest.permission.READ_EXTERNAL_STORAGE
                val permissionState = rememberPermissionState(permission)
                if (!permissionState.status.isGranted) {
                    PermissionScreen { permissionState.launchPermissionRequest() }
                } else {
                    val currentSong by playerController.currentSong.collectAsState()
                    val isPlaying by playerController.isPlaying.collectAsState()
                    if (showSettings) {
                        SettingsScreen(
                            prefs = prefs,
                            currentTheme = themeName,
                            onThemeChange = {
                                prefs.theme = it
                                themeName = it
                            },
                            onRescan = { repo.loadSongs(forceRefresh = true); refreshKey++ },
                            onClose = { showSettings = false },
                            playerController = playerController
                        )
                    } else if (showPlayer && currentSong != null) {
                        PlayerScreen(
                            playerController = playerController,
                            allSongs = allSongs,
                            onClose = { showPlayer = false },
                            onFavoriteChanged = { refreshKey++ }
                        )
                    } else {
                        Scaffold(
                            containerColor = MaterialTheme.colorScheme.background,
                            topBar = {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(onClick = { showSettings = true }) {
                                        Icon(Icons.Default.Menu, "Settings", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            },
                            bottomBar = {
                                Column {
                                    currentSong?.let { song ->
                                        MiniPlayer(
                                            song = song,
                                            isPlaying = isPlaying,
                                            onTogglePlay = { playerController.togglePlayPause() },
                                            onNext = { playerController.seekToNext() },
                                            onExpand = { showPlayer = true }
                                        )
                                    }
                                    BottomTabs(selectedTab, prefs.animations) { selectedTab = it }
                                }
                            }
                        ) { padding ->
                            Box(Modifier.fillMaxSize().padding(padding)) {
                                Crossfade(targetState = selectedTab, animationSpec = tween(220), label = "tab") { tab ->
                                        when (tab) {
                                            0 -> HomeScreen(
                                                onPlaySong = { song, all ->
                                                    playerController.playSong(song, all.ifEmpty { listOf(song) })
                                                    playerController.setShuffle(prefs.shuffle)
                                                    playerController.setRepeatMode(if (prefs.repeatOne) androidx.media3.common.Player.REPEAT_MODE_ONE else androidx.media3.common.Player.REPEAT_MODE_OFF)
                                                    if (!prefs.autoplay) playerController.pause()
                                                    if (prefs.listeningHistory) kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { repo.recordPlay(song.id) }
                                                    showPlayer = true
                                                },
                                                onViewAllSongs = { selectedTab = 2 }
                                            )
                                            1 -> OnlineMusicScreen()
                                            2 -> LibraryScreen(
                                                playlistStore = playlistStore,
                                                allSongsProvider = { allSongs },
                                                favoriteSongsProvider = { repo.getFavoriteSongs() },
                                                onPlaySong = { song, list ->
                                                    playerController.playSong(song, list.ifEmpty { allSongs })
                                                    playerController.setShuffle(prefs.shuffle)
                                                    playerController.setRepeatMode(if (prefs.repeatOne) androidx.media3.common.Player.REPEAT_MODE_ONE else androidx.media3.common.Player.REPEAT_MODE_OFF)
                                                    if (!prefs.autoplay) playerController.pause()
                                                    if (prefs.listeningHistory) kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { repo.recordPlay(song.id) }
                                                    showPlayer = true
                                                }
                                            )
                                            else -> SearchScreen(
                                                allSongs = allSongs,
                                                onPlaySong = { song ->
                                                    val all = allSongs
                                                    playerController.playSong(song, all.ifEmpty { listOf(song) })
                                                    playerController.setShuffle(prefs.shuffle)
                                                    playerController.setRepeatMode(if (prefs.repeatOne) androidx.media3.common.Player.REPEAT_MODE_ONE else androidx.media3.common.Player.REPEAT_MODE_OFF)
                                                    if (!prefs.autoplay) playerController.pause()
                                                    if (prefs.listeningHistory) kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { repo.recordPlay(song.id) }
                                                    showPlayer = true
                                                }
                                            )
                                        }
                                    }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomTabs(selected: Int, animate: Boolean, onSelect: (Int) -> Unit) {
    val tabs = listOf(
        "Home" to Icons.Default.Home,
        "Online" to Icons.Default.Public,
        "Library" to Icons.Default.LibraryMusic,
        "Search" to Icons.Default.Search
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f), tonalElevation = 0.dp) {
        tabs.forEachIndexed { index, (label, icon) ->
            val scale by animateFloatAsState(
                targetValue = if (selected == index) 1.12f else 1f,
                animationSpec = spring(dampingRatio = 0.45f, stiffness = 550f),
                label = "tabScale"
            )
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icon, label, modifier = Modifier.scale(if (animate) scale else 1f)) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f),
                    unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f),
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(Modifier.fillMaxSize()) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.example.offlinemusic.R.mipmap.ic_launcher),
            contentDescription = "Modih Music",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .16f)))
    }
}

@Composable
private fun WelcomeScreen(onContinue: () -> Unit) {
    androidx.compose.foundation.lazy.LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        item {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(com.example.offlinemusic.R.mipmap.ic_launcher),
                contentDescription = "Modih Music",
                modifier = Modifier.padding(bottom = 22.dp)
            )
            Text("Welcome to Modih Music", color = MaterialTheme.colorScheme.onBackground, fontSize = 30.sp)
            Spacer(Modifier.height(18.dp))
            Text(
                "If you're not a music lover then bhad me jao, yaha kyu aaye ho?\n\nAnd music lovers, we welcome you in Modih's Music.",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = .72f),
                fontSize = 17.sp,
                lineHeight = 25.sp
            )
            Spacer(Modifier.height(34.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Continue", fontSize = 18.sp) }
        }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
            Text("Your music library needs access", color = MaterialTheme.colorScheme.onBackground, fontSize = 22.sp)
            Spacer(Modifier.height(10.dp))
            Text("Allow Modih's Music to read local songs, artwork and metadata.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
            Spacer(Modifier.height(20.dp))
            Button(onClick = onGrant) { Text("Grant Permission") }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)
