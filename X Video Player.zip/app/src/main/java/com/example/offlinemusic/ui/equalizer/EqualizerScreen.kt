package com.example.offlinemusic.ui.equalizer

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EqualizerScreen(onClose: () -> Unit) {
    var enabled by remember { mutableStateOf(true) }
    var eq by remember { mutableStateOf<Equalizer?>(null) }
    var bass by remember { mutableStateOf<BassBoost?>(null) }
    var available by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        try {
            eq = Equalizer(0, 0).apply { enabled = true }
            bass = BassBoost(0, 0).apply { enabled = true }
        } catch (_: Throwable) {
            available = false
        }
        onDispose {
            runCatching { eq?.release() }
            runCatching { bass?.release() }
        }
    }

    val e = eq
    val bandCount = e?.numberOfBands?.toInt() ?: 5
    val minMb = e?.bandLevelRange?.getOrNull(0)?.toInt() ?: -1500
    val maxMb = e?.bandLevelRange?.getOrNull(1)?.toInt() ?: 1500
    val values = remember(bandCount) { List(bandCount) { mutableFloatStateOf(0.5f) } }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Back", tint = MaterialTheme.colorScheme.primary) }
            Text("Equalizer", color = MaterialTheme.colorScheme.onBackground, fontSize = 28.sp)
        }
        if (!available) {
            Text("The device does not expose an audio equalizer effect.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f), modifier = Modifier.padding(24.dp))
            return@Column
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("Equalizer", color = MaterialTheme.colorScheme.onBackground); Text("Applies through Android audio effects when supported", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), fontSize = 12.sp) }
            Switch(checked = enabled, onCheckedChange = { enabled = it; runCatching { e?.enabled = it; bass?.enabled = it } })
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
            for (i in 0 until bandCount) {
                val center = e?.getCenterFreq(i.toShort())?.div(1000) ?: 0
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Slider(
                        value = values[i].floatValue,
                        onValueChange = { v -> values[i].floatValue = v; val level = (minMb + (maxMb - minMb) * v).toInt().toShort(); runCatching { e?.setBandLevel(i.toShort(), level) } },
                        modifier = Modifier.height(210.dp).width(48.dp)
                    )
                    Text(if (center >= 1000) "${center / 1000}k" else "${center}Hz", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f), fontSize = 10.sp)
                }
            }
        }
        Text("Bass Boost", color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp))
        Slider(value = 0.35f, onValueChange = { runCatching { bass?.setStrength((it * 1000).toInt().toShort()) } }, modifier = Modifier.padding(horizontal = 20.dp))
    }
}
