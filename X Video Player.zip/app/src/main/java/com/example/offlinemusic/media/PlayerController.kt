package com.example.offlinemusic.media

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.offlinemusic.data.model.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PlayerController(private val context: Context) {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val songMap = mutableMapOf<String, Song>()

    fun connect() {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(playerListener)
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.mediaId?.let { id ->
                _currentSong.value = songMap[id]
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            controller?.let {
                _duration.value = it.duration.coerceAtLeast(0)
                _position.value = it.currentPosition
            }
        }
    }

    fun playSong(song: Song, queueSongs: List<Song> = listOf(song)) {
        songMap.clear()
        queueSongs.forEach { songMap[it.id.toString()] = it }
        _queue.value = queueSongs
        _currentSong.value = song

        val items = queueSongs.map {
            MediaItem.Builder()
                .setMediaId(it.id.toString())
                .setUri(it.contentUri)
                .setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(it.title)
                        .setArtist(it.artist)
                        .setAlbumTitle(it.album)
                        .build()
                )
                .build()
        }
        val index = queueSongs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        controller?.setMediaItems(items, index, 0)
        controller?.prepare()
        controller?.play()
    }

    fun play() = controller?.play()
    fun pause() = controller?.pause()
    fun togglePlayPause() {
        if (controller?.isPlaying == true) pause() else play()
    }

    fun seekTo(pos: Long) = controller?.seekTo(pos)
    fun seekToNext() = controller?.seekToNext()
    fun seekToPrevious() = controller?.seekToPrevious()

    fun updatePosition() {
        controller?.let {
            _position.value = it.currentPosition
            _duration.value = it.duration.coerceAtLeast(0)
        }
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
    }

    fun setRepeatMode(mode: Int) {
        controller?.repeatMode = mode
    }
}
